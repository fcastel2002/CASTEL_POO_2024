from menu import Usuario

if __name__ == "__main__":
    usuario = Usuario("COM5")
    usuario.command_menu()
