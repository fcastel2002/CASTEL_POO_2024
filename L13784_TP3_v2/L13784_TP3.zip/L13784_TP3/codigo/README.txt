Dentro de la carpeta XMLRPC++ se encuentran los .h y .cpp, con sus respectivas modificaciones para su funcionamiento en Windows (tambi�n se encuentra en la carpeta "anexos").

Dentro de la carpeta "x64" se encuentran dos carpetas, "Release" y "Debug".

Pasos para la ejecuci�n:
	1- Dirigirse a la carpeta "Release"
	2- Ejecutar "cmd" o "PowerShell" con direcci�n en ella.
	3- Ejecutar los .exe como explica el informe.
